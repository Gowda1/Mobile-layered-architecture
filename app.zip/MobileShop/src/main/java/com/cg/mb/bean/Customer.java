package com.cg.mb.bean;

public class Customer 
{
	private int customerID;
	private String name;
	private String address;
	private String mobileNumber;
	
	public int getCustomerID() 
	{
		return customerID;
	}

	public void setCustomerID(int customerID) 
	{
		this.customerID = customerID;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public String getAddress() 
	{
		return address;
	}

	public void setAddress(String address) 
	{
		this.address = address;
	}

	public String getMobileNumber() 
	{
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) 
	{
		this.mobileNumber = mobileNumber;
	}
	
	public Customer()
	{
		name = null;
		address = null;
		mobileNumber = null;
	}
	
	public Customer(String name,String address,String mobileNumber) 
	{	
		this.name = name;
		this.address = address;
		this.mobileNumber = mobileNumber;
	}
		
	@Override
	public String toString()
	{
		return ""
						+ "Customer Id: " + customerID 
						+ "\nCustomer Name: " + name 
						+ "\nAddress: " + address
						+ "\nMobileNumber: " + mobileNumber;
	}	
}
