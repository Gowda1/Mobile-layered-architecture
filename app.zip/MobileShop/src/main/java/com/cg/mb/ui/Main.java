package com.cg.mb.ui;

import java.io.UnsupportedEncodingException;
import java.util.Scanner;

import com.cg.mb.service.BuyMobile;

public class Main 
{
	public static void main(String[] args) throws UnsupportedEncodingException
	{
		Scanner input = new Scanner(System.in);
		BuyMobile store = new BuyMobile();
		boolean bool = true;
		
		while(bool)
		{
			System.out.println("\t\t\t\t-----WELCOME TO ROCKSTAR MOBILES-----");
			System.out.println();
			System.out.println("Enter your choice:");
			System.out.println("1. Purchase Mobile");
			System.out.println("2. View Bill");
		
			System.out.println();
			
			System.out.print("Your Choice:");
			switch(input.nextInt()) 
			{
				case 1: store.purchaseMobile(); break;
				case 2: store.getPurchasedetials(); break;
				case 0: bool = false; break;
				default: System.out.println("Not a valid option."); break;
			}					
		}	
		input.close();
	}
}
