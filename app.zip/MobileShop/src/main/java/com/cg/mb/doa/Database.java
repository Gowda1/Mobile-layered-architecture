package com.cg.mb.doa;

import java.util.HashMap;
import java.util.Map;

import com.cg.mb.bean.Bill;
import com.cg.mb.bean.Customer;
import com.cg.mb.bean.Mobile;

public class Database 
{
	Map<Integer,Mobile> mobileDetails = new HashMap<Integer, Mobile>();
	Map<Integer,Customer> customerDetails = new HashMap<Integer,Customer>();
	Map<Integer,Bill> billDatabase = new HashMap<Integer, Bill>(); 
	
	public Database()
	{
		mobileDetails.put(1, new Mobile(1,"Samsung S1",10000));
		mobileDetails.put(2, new Mobile(2,"Samsung S2",20000));
		mobileDetails.put(3, new Mobile(3,"Samsung S3",30000));
		mobileDetails.put(4, new Mobile(4,"Samsung S4",40000));
		mobileDetails.put(5, new Mobile(5,"Samsung S5",50000));
		mobileDetails.put(6, new Mobile(6,"Samsung S6",60000));
		mobileDetails.put(7, new Mobile(7,"Samsung S7",70000));
		mobileDetails.put(8, new Mobile(8,"Samsung S8",80000));
		mobileDetails.put(9, new Mobile(9,"Samsung S9",90000));
		mobileDetails.put(10, new Mobile(10,"Samsung S10",100000));
	}
	
	//Print all data from map 
	public void displayAllMobiles()
	{
		for(Integer aKey : mobileDetails.keySet())
		{
				Mobile aValue = mobileDetails.get(aKey);
				System.out.println(aValue);	
		}
		
	}
	
	//Mobile Map
	public Mobile getMobile(int mobileModelNumber)
	{
		return mobileDetails.get(mobileModelNumber);
	}
	
	//Customer Map
	public void storeIntoMap(Customer customer) 
	{
		customerDetails.put(customer.getCustomerID(), customer);
	}
	
	public Customer getFromMap(int customerID)
	{
		return customerDetails.get(customerID);
	}
	
	//Bill Map
	public void storeIntoBillDatabase(Bill bill) 
	{
		billDatabase.put(bill.getOrderID(), bill);
	}
	
	public Bill getFromBillDatabase(int orderID)
	{
		return billDatabase.get(orderID);
	}
	
	
	
}
