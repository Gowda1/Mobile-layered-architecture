package com.cg.mb.bean;

public class Mobile extends Customer
{
	private int mobileModelNumber;
	private String mobileModel;
	private float mobilePrice; 
	
	public Mobile()
	{
		this.mobileModelNumber = 0; 
		this.mobileModel = null;
		this.mobilePrice = 0f;
	}
	
	public Mobile(int mobileModelNumber, String mobileModel, float mobilePrice)
	{		
		this.mobileModelNumber = mobileModelNumber;
		this.mobileModel = mobileModel;
		this.mobilePrice = mobilePrice;
	}
	
	public int getMobileModelNumber() 
	{
		return mobileModelNumber;
	}

	public void setMobileModelNumber(int mobileModelNumber) 
	{
		this.mobileModelNumber = mobileModelNumber;
	}

	public String getMobileModel() 
	{
		return mobileModel;
	}
	
	public void setMobileModel(String mobileModel)
	{
		this.mobileModel = mobileModel;
	}
	
	public float getMobilePrice() 
	{
		return mobilePrice;
	}
	
	public void setMobilePrice(float mobilePrice) 
	{
		this.mobilePrice = mobilePrice;
	}
	
	@Override
	public String toString()
	{
		return ""
						+ "Model Number: " + mobileModelNumber 
						+ "\nModel: " + mobileModel
						+ "\nPrice: " + mobilePrice + "\n";
	}	
}
