package com.cg.mb.service;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.cg.mb.bean.*;
import com.cg.mb.doa.Database;

public class BuyMobile 
{
	Scanner input = new Scanner(System.in);
	Database db = new Database();
	int orderID;
	int customerID;
	
	
	//Enroll Customer
	public void purchaseMobile() throws UnsupportedEncodingException 
	{
		//Customer Database
		boolean bool = true;
		Customer customer = new Customer();
		System.out.println();
		
		//Set Customer ID
		customer.setCustomerID(++customerID);
		
		//Set Customer Name
		System.out.println("Enter your Name:");
		customer.setName(input.next());
		
		//Set Customer City
		System.out.println("Enter your City:");
		customer.setAddress(input.next());
		
		//Set Customer Mobile Number
		System.out.println("Enter your Mobile Number:");
		customer.setMobileNumber(input.next());
		
		//Store Customer Object into Map
		db.storeIntoMap(customer);
		
		//Mobile Database
		Mobile mobile = new Mobile();
		
		System.out.println("Choose Mobile:");
		System.out.println();
		db.displayAllMobiles();
		
		while(bool)
		{
			System.out.print("Choose model number:");
			int choice = input.nextInt();
			if(choice > 0 && choice <= 10)
				{ mobile = db.getMobile(choice); bool = false; }  
			else
				System.out.println("Not a valid model number.");
		}
			
		//Bill Database
		Bill bill = new Bill();
		
		//Customer data
		bill.setCustomerID(customerID);
		bill.setName(customer.getName());
		bill.setAddress(customer.getAddress());
		bill.setMobileNumber(customer.getMobileNumber());
		
		//Mobile Data
		bill.setMobileModel(mobile.getMobileModel());
		bill.setMobileModelNumber(mobile.getMobileModelNumber());
		bill.setMobilePrice(mobile.getMobilePrice());
		
		//Order Data
		bill.setOrderID(++orderID);
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		bill.setPurchaseDate(dateFormat.format(new Date()));
		bill.setPriceWithGST(mobile.getMobilePrice() + (mobile.getMobilePrice() * 0.05f));
		
		db.storeIntoBillDatabase(bill);
		
		System.out.println();
		System.out.println("-----Purchase Successful----");
		System.out.println();
		System.out.println(bill);

	}
	
	//Generate bill
	public void getPurchasedetials() 
	{
		System.out.println();
		System.out.println("To view your bill - ");
		System.out.print("Enter order ID: ");
		System.out.println(db.getFromBillDatabase(input.nextInt()));
	}
	
}
