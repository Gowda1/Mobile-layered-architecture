package com.cg.mb.bean;


public class Bill extends Mobile
{
	private int orderID;
	private String purchaseDate;
	private float priceWithGST;

	public static final String RUPEE = "\u20B9";
	
	public int getOrderID() 
	{
		return orderID;
	}

	public void setOrderID(int orderID) 
	{
		this.orderID = orderID;
	}

	public String getPurchaseDate() 
	{
		return purchaseDate;
	}
	
	public void setPurchaseDate(String purchaseDate) 
	{
		this.purchaseDate = purchaseDate;
	}
	
	public float getPriceWithGST() 
	{
		return priceWithGST;
	}

	public void setPriceWithGST(float priceWithGST) 
	{
		this.priceWithGST = priceWithGST;
	}
	
	@Override
	public String toString()
	{
		return ""
						+ "Order ID: " + orderID 
						+ "\nPurchase Date: " + purchaseDate
						+ "\nCustomer ID: " + getCustomerID()
						+ "\nCustomer Name: " + getName()
						+ "\nCustomer City: " + getAddress()
						+ "\nModel Number: " + getMobileModelNumber()
						+ "\nModel: " + getMobileModel() 
						+ "\nPrice: " + getMobilePrice() + RUPEE
						+ "\nPrice With GST: " + priceWithGST + RUPEE + "\n";
	}	
}
